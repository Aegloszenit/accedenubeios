//
//  ViewController.swift
//  isbnapp
//
//  Created by Alejandro Martinez Montero on 28/3/18.
//  Copyright © 2018 Alejandro Martinez Montero. All rights reserved.
//

import UIKit
import SystemConfiguration

class ViewController: UIViewController {

    @IBOutlet weak var searchText: UITextField!

    @IBOutlet weak var authorsLabelText: UILabel!
    @IBOutlet weak var coverImage: UIImageView!
    @IBOutlet weak var titlesbook: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func specificData(rawTextToConvert: Data)  {
        let myJson = try? JSONSerialization.jsonObject(with: rawTextToConvert, options: JSONSerialization.ReadingOptions.mutableLeaves)
        
        let myDictionary = myJson as! NSDictionary
        let myStringtitle = "ISBN:" + searchText.text!

        let myInsertedDict = myDictionary[myStringtitle] as! NSDictionary
        let bookTitle = myInsertedDict["title"] as! NSString
        titlesbook.text = bookTitle as String
        print(myDictionary[myStringtitle]  ?? "nothing to see")
        let coverHttpPage = URL(string: "http://covers.openlibrary.org/b/ISBN/" + searchText.text! + "-M.jpg")
        let theAuthors = myInsertedDict["authors"] as! NSArray
        print(theAuthors.count)
        
        var authorsTextNames = ""
        for authorItem in theAuthors {
            let objectItem = authorItem as! NSDictionary
            authorsTextNames += (objectItem["name"] as! NSString) as String
            authorsTextNames += ", "
        }
        authorsLabelText.text = authorsTextNames
        coverImage.isHidden = false
        if let myImageBook = try? Data(contentsOf: coverHttpPage!) {
            coverImage.image = UIImage(data: myImageBook)
        }
        //http://covers.openlibrary.org/b/$key/$value-$size.jpg
        //key can be any one of ISBN, OCLC, LCCN, OLID and ID (case-insensitive)
        //value is the value of the chosen key
        //size can be one of S, M and L for small, medium and large respectively. 
        
    }
    

    func sincrono() {
        let urls = "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:" + searchText.text!
        let url = NSURL(string: urls)
        let datos:NSData? = NSData(contentsOf: url! as URL)
        specificData(rawTextToConvert: datos! as Data)
        let texto = NSString(data: datos! as Data, encoding: String.Encoding.utf8.rawValue)
        //print(texto!)
        //textViewElement.text = texto! as String
    }
    
    func isInternetAvailable() -> Bool
    {
        var zeroAddress = sockaddr_in()
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
        
        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
            }
        }
        
        var flags = SCNetworkReachabilityFlags()
        if !SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) {
            return false
        }
        let isReachable = flags.contains(.reachable)
        let needsConnection = flags.contains(.connectionRequired)
        return (isReachable && !needsConnection)
    }

    @IBAction func searchISBNinTheWeb(_ sender: Any) {
        print("works")
        let xx = isInternetAvailable()
        if xx == true {
            sincrono()
        }
        else {
            authorsLabelText.text = "no internet connection"
            titlesbook.text = "no internet connection"
            //textViewElement.text = "There is no internet or the site is not correct"
        }
        
    }
    
    @IBAction func clearActionOfText(_ sender: Any) {
        //textViewElement.text = ""
        authorsLabelText.text = ""
        titlesbook.text = ""
        coverImage.isHidden = true
        
        
    }
}

